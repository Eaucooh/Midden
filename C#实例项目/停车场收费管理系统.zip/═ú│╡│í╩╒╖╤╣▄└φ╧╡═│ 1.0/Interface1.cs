﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 停车场项目
{
    /// <summary>
    /// 打印
    /// </summary>
    public interface Iprint
    {
        void Print(string a,string b);
    }
}
