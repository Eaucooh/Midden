﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BrithdayEigth
{
    class Map
    {
        private string key;

        public string Key
        {
            get { return key; }
            set { key = value; }
        }

        private string value;

        public string Value
        {
            get { return this.value; }
            set { this.value = value; }
        }
    }
}
